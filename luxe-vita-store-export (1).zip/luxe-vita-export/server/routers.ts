import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getCategories, getAllProducts, getProductsByCategory, getProductById, createWholesaleInquiry } from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  catalog: router({
    categories: publicProcedure.query(async () => {
      return await getCategories();
    }),
    products: publicProcedure.query(async () => {
      return await getAllProducts();
    }),
    productsByCategory: publicProcedure
      .input(z.number())
      .query(async ({ input: categoryId }) => {
        return await getProductsByCategory(categoryId);
      }),
    productById: publicProcedure
      .input(z.number())
      .query(async ({ input: productId }) => {
        return await getProductById(productId);
      }),
  }),

  inquiries: router({
    submit: publicProcedure
      .input(
        z.object({
          companyName: z.string().min(1),
          contactPerson: z.string().min(1),
          email: z.string().email(),
          phone: z.string().min(1),
          businessType: z.string().optional(),
          productsOfInterest: z.string().optional(),
          desiredQuantity: z.string().optional(),
          message: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await createWholesaleInquiry(input);
      }),
  }),
});

export type AppRouter = typeof appRouter;
