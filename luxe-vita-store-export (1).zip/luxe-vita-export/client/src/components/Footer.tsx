import { Link } from "wouter";
import { MessageCircle, Mail, MapPin } from "lucide-react";

const WHATSAPP_NUMBER = "07082769477";
const STORE_ADDRESS = "Oke Baale, Ona Baba Ona, Osogbo, Osun State";

const SOCIAL_LINKS = [
  { name: "Instagram", url: "https://instagram.com/luxe_vita_store", icon: "📷" },
  { name: "TikTok", url: "https://tiktok.com/@luxe_vita_store_backup", icon: "🎵" },
];

const QUICK_LINKS = [
  { label: "Home", href: "/" },
  { label: "Catalog", href: "/catalog" },
  { label: "Wholesale", href: "/wholesale" },
  { label: "Contact", href: "/contact" },
];

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-900 text-slate-100 pt-16 pb-8">
      <div className="container mx-auto px-4">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Brand Section */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center text-white text-sm font-bold">
                LV
              </div>
              <span className="font-bold text-lg">Luxe Vita Store</span>
            </div>
            <p className="text-slate-400 text-sm mb-4">
              Premium wholesale products for your business. Quality, affordability, and exceptional service.
            </p>
            <div className="flex gap-3">
              {SOCIAL_LINKS.map((social) => (
                <a
                  key={social.name}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  title={social.name}
                  className="w-10 h-10 bg-slate-800 hover:bg-blue-600 rounded-lg flex items-center justify-center transition-colors"
                >
                  <span className="text-lg">{social.icon}</span>
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold text-white mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {QUICK_LINKS.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-slate-400 hover:text-white transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-semibold text-white mb-4">Contact</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-3">
                <MessageCircle className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
                <a
                  href={`https://wa.me/${WHATSAPP_NUMBER.replace(/\D/g, "")}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-slate-400 hover:text-white transition-colors"
                >
                  {WHATSAPP_NUMBER}
                </a>
              </li>
              <li className="flex items-start gap-3">
                <Mail className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
                <a
                  href="mailto:inquiries@luxevitastore.com"
                  className="text-slate-400 hover:text-white transition-colors"
                >
                  inquiries@luxevitastore.com
                </a>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
                <span className="text-slate-400">{STORE_ADDRESS}</span>
              </li>
            </ul>
          </div>

          {/* Business Hours */}
          <div>
            <h3 className="font-semibold text-white mb-4">Business Hours</h3>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>
                <span className="font-medium text-white">Monday - Sunday</span>
                <p>24/7 Support Available</p>
              </li>
              <li className="pt-2 border-t border-slate-800">
                <p className="text-xs font-semibold text-slate-500 mb-2">WHOLESALE INQUIRIES</p>
                <p>Contact us anytime for bulk orders and partnership opportunities</p>
              </li>
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-slate-800 pt-8">
          {/* Bottom Footer */}
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-slate-400 text-sm">
              © {currentYear} Luxe Vita Store. All rights reserved.
            </p>
            <div className="flex gap-6 text-sm text-slate-400">
              <span>Privacy Policy</span>
              <span>Terms of Service</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
