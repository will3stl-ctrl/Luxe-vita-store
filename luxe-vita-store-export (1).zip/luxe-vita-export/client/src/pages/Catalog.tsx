import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Search, ShoppingCart, X, MessageCircle } from "lucide-react";
import { useLocation } from "wouter";

const WHATSAPP_NUMBER = "07082769477";

export default function Catalog() {
  const [location] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [inquiryList, setInquiryList] = useState<any[]>([]);
  const [showInquiryList, setShowInquiryList] = useState(false);

  const categoriesQuery = trpc.catalog.categories.useQuery();
  const productsQuery = trpc.catalog.products.useQuery();

  // Load inquiry list from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("inquiryList");
    if (saved) {
      try {
        setInquiryList(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load inquiry list:", e);
      }
    }

    // Check URL params for category filter
    const params = new URLSearchParams(location.split("?")[1] || "");
    const categoryId = params.get("category");
    if (categoryId) {
      setSelectedCategory(categoryId);
    }
  }, []);

  // Save inquiry list to localStorage
  useEffect(() => {
    localStorage.setItem("inquiryList", JSON.stringify(inquiryList));
  }, [inquiryList]);

  const filteredProducts = productsQuery.data?.filter((product: any) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = !selectedCategory || product.categoryId.toString() === selectedCategory;
    return matchesSearch && matchesCategory;
  }) || [];

  const addToInquiryList = (product: any) => {
    const existing = inquiryList.find((item) => item.id === product.id);
    if (!existing) {
      setInquiryList([...inquiryList, { ...product, inquiryQuantity: 1 }]);
    }
  };

  const removeFromInquiryList = (productId: number) => {
    setInquiryList(inquiryList.filter((item) => item.id !== productId));
  };

  const updateInquiryQuantity = (productId: number, quantity: number) => {
    setInquiryList(
      inquiryList.map((item) =>
        item.id === productId ? { ...item, inquiryQuantity: Math.max(1, quantity) } : item
      )
    );
  };

  const generateInquiryText = () => {
    const items = inquiryList
      .map((item) => `- ${item.name}: ${item.inquiryQuantity} units`)
      .join("\n");
    return `Hello Luxe Vita Store,\n\nI'm interested in the following products:\n\n${items}\n\nPlease provide pricing and availability information.`;
  };

  const handleWhatsAppInquiry = () => {
    const text = encodeURIComponent(generateInquiryText());
    window.open(`https://wa.me/${WHATSAPP_NUMBER.replace(/\D/g, "")}?text=${text}`, "_blank");
  };

  return (
    <div className="min-h-screen bg-background pt-24 pb-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Product Catalog</h1>
          <p className="text-lg text-muted-foreground">
            Browse our wholesale products and add items to your inquiry list
          </p>
        </div>

        {/* Filters and Search */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
            <Input
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          <Select value={selectedCategory || "all"} onValueChange={(value) => setSelectedCategory(value === "all" ? null : value)}>
            <SelectTrigger>
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categoriesQuery.data?.map((category: any) => (
                <SelectItem key={category.id} value={category.id.toString()}>
                  {category.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button
            onClick={() => setShowInquiryList(!showInquiryList)}
            variant={showInquiryList ? "default" : "outline"}
            className="w-full"
          >
            <ShoppingCart className="mr-2 h-5 w-5" />
            Inquiry List ({inquiryList.length})
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Products Grid */}
          <div className="lg:col-span-3">
            {filteredProducts.length === 0 ? (
              <Card className="p-12 text-center">
                <p className="text-muted-foreground text-lg">No products found matching your criteria.</p>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredProducts.map((product: any) => (
                  <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                    {/* Product Image */}
                    <div className="aspect-square bg-gradient-to-br from-slate-200 to-slate-300 dark:from-slate-700 dark:to-slate-800 flex items-center justify-center">
                      {product.imageUrl ? (
                        <img
                          src={product.imageUrl}
                          alt={product.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="text-muted-foreground">No image</div>
                      )}
                    </div>

                    {/* Product Info */}
                    <div className="p-4">
                      <h3 className="font-semibold text-foreground mb-2 line-clamp-2">{product.name}</h3>
                      <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                        {product.description}
                      </p>

                      {/* Product Details */}
                      <div className="space-y-2 mb-4 text-sm">
                        {product.moq && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">MOQ:</span>
                            <span className="font-medium">{product.moq} units</span>
                          </div>
                        )}
                        {product.material && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Material:</span>
                            <span className="font-medium">{product.material}</span>
                          </div>
                        )}
                        {product.leadTime && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Lead Time:</span>
                            <span className="font-medium">{product.leadTime}</span>
                          </div>
                        )}
                      </div>

                      {/* Action Button */}
                      <Button
                        onClick={() => addToInquiryList(product)}
                        disabled={inquiryList.some((item) => item.id === product.id)}
                        className="w-full"
                        variant={inquiryList.some((item) => item.id === product.id) ? "secondary" : "default"}
                      >
                        {inquiryList.some((item) => item.id === product.id)
                          ? "✓ Added to Inquiry"
                          : "Add to Inquiry"}
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Inquiry List Sidebar */}
          {showInquiryList && (
            <div className="lg:col-span-1">
              <Card className="sticky top-24 p-6">
                <h3 className="text-lg font-semibold text-foreground mb-4">Inquiry List</h3>

                {inquiryList.length === 0 ? (
                  <p className="text-muted-foreground text-sm">No items added yet</p>
                ) : (
                  <>
                    <div className="space-y-4 mb-6 max-h-96 overflow-y-auto">
                      {inquiryList.map((item) => (
                        <div key={item.id} className="border-b pb-4 last:border-b-0">
                          <div className="flex justify-between items-start mb-2">
                            <p className="font-medium text-sm text-foreground line-clamp-2">{item.name}</p>
                            <button
                              onClick={() => removeFromInquiryList(item.id)}
                              className="text-muted-foreground hover:text-foreground"
                            >
                              <X className="h-4 w-4" />
                            </button>
                          </div>
                          <div className="flex items-center gap-2">
                            <Input
                              type="number"
                              min="1"
                              value={item.inquiryQuantity}
                              onChange={(e) =>
                                updateInquiryQuantity(item.id, parseInt(e.target.value) || 1)
                              }
                              className="w-16 h-8 text-sm"
                            />
                            <span className="text-xs text-muted-foreground">units</span>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Action Buttons */}
                    <div className="space-y-2">
                      <Link href="/contact">
                        <Button className="w-full" size="sm">
                          Submit Inquiry
                        </Button>
                      </Link>
                      <Button
                        onClick={handleWhatsAppInquiry}
                        variant="outline"
                        size="sm"
                        className="w-full"
                      >
                        <MessageCircle className="mr-2 h-4 w-4" />
                        Send via WhatsApp
                      </Button>
                    </div>
                  </>
                )}
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
