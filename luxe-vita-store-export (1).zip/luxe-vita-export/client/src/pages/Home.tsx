import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Link } from "wouter";
import { ShoppingBag, Package, Zap, ChefHat, Sparkles, MessageCircle } from "lucide-react";

const WHATSAPP_NUMBER = "07082769477";
const WHATSAPP_URL = `https://wa.me/${WHATSAPP_NUMBER.replace(/\D/g, "")}?text=Hello%20Luxe%20Vita%20Store%2C%20I%27m%20interested%20in%20wholesale%20inquiries.`;

const CATEGORIES_SHOWCASE = [
  {
    id: 1,
    name: "Children's Shoes",
    icon: ShoppingBag,
    description: "Premium quality children's footwear",
    color: "from-pink-500 to-rose-500",
  },
  {
    id: 2,
    name: "Kids' Apparel",
    icon: Package,
    description: "Comfortable and stylish clothing",
    color: "from-blue-500 to-cyan-500",
  },
  {
    id: 3,
    name: "Electronics & Gadgets",
    icon: Zap,
    description: "Latest tech and gadgets",
    color: "from-purple-500 to-indigo-500",
  },
  {
    id: 4,
    name: "Kitchenware",
    icon: ChefHat,
    description: "Quality kitchen essentials",
    color: "from-orange-500 to-red-500",
  },
  {
    id: 5,
    name: "Skincare & Fragrance",
    icon: Sparkles,
    description: "Premium beauty products",
    color: "from-emerald-500 to-teal-500",
  },
];

export default function Home() {
  const [scrollY, setScrollY] = useState(0);
  const categoriesQuery = trpc.catalog.categories.useQuery();

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
        {/* Animated background gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 z-0" />
        <div
          className="absolute inset-0 opacity-30 z-0"
          style={{
            backgroundImage: `radial-gradient(circle at ${50 + scrollY * 0.05}% ${50 + scrollY * 0.05}%, rgba(59, 130, 246, 0.2) 0%, transparent 50%)`,
          }}
        />

        {/* Hero Content */}
        <div className="relative z-10 container mx-auto px-4 text-center max-w-4xl">
          <div className="mb-8 inline-block">
            <div className="px-4 py-2 rounded-full bg-blue-500/20 border border-blue-500/50 backdrop-blur-sm">
              <p className="text-sm font-medium text-blue-300">Welcome to Luxe Vita Store</p>
            </div>
          </div>

          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
            Premium Wholesale Products for Your Business
          </h1>

          <p className="text-xl md:text-2xl text-slate-300 mb-12 max-w-2xl mx-auto">
            Discover our curated collection of children's products, electronics, kitchenware, and more. Partner with us for quality wholesale solutions.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link href="/catalog">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg">
                Explore Catalog
              </Button>
            </Link>
            <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer">
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white/10 px-8 py-6 text-lg"
              >
                <MessageCircle className="mr-2 h-5 w-5" />
                Chat on WhatsApp
              </Button>
            </a>
          </div>

          {/* Trust badges */}
          <div className="flex flex-wrap justify-center gap-6 text-slate-400">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full" />
              <span>Verified Seller</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full" />
              <span>Fast Delivery</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full" />
              <span>Quality Assured</span>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 animate-bounce">
          <div className="w-6 h-10 border-2 border-blue-500 rounded-full flex items-start justify-center p-2">
            <div className="w-1 h-2 bg-blue-500 rounded-full animate-pulse" />
          </div>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Our Product Categories
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Browse our diverse range of wholesale products across multiple categories
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            {CATEGORIES_SHOWCASE.map((category) => {
              const Icon = category.icon;
              return (
                <Link key={category.id} href={`/catalog?category=${category.id}`}>
                  <Card className="h-full cursor-pointer hover:shadow-lg transition-all duration-300 hover:-translate-y-1 bg-card border-border overflow-hidden group">
                    <div
                      className={`h-32 bg-gradient-to-br ${category.color} opacity-10 group-hover:opacity-20 transition-opacity`}
                    />
                    <div className="p-6">
                      <Icon className="w-8 h-8 text-primary mb-4" />
                      <h3 className="text-lg font-semibold text-card-foreground mb-2">
                        {category.name}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {category.description}
                      </p>
                    </div>
                  </Card>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Brand Story */}
      <section className="py-20 bg-slate-50 dark:bg-slate-900/50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
                About Luxe Vita Store
              </h2>
              <p className="text-lg text-muted-foreground mb-4 leading-relaxed">
                Luxe Vita Store is your trusted partner for premium wholesale products. Located in Osogbo, Osun State, we have built our reputation on quality, affordability, and exceptional customer service.
              </p>
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                With years of experience in the retail and wholesale business, we understand the needs of B2B buyers. Our carefully curated selection of children's products, electronics, kitchenware, and beauty items ensures you get the best value for your business.
              </p>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                We are committed to providing competitive pricing, flexible MOQs, and reliable delivery to support your business growth.
              </p>
              <Link href="/wholesale">
                <Button size="lg" className="bg-primary hover:bg-primary/90">
                  Learn More About Wholesale
                </Button>
              </Link>
            </div>
            <div className="relative">
              <div className="aspect-square bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl opacity-20" />
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-600/10 rounded-2xl border border-blue-500/20 backdrop-blur-sm flex items-center justify-center">
                <div className="text-center">
                  <p className="text-6xl font-bold text-primary mb-2">100%</p>
                  <p className="text-xl text-muted-foreground">Verified Quality</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-blue-700">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Ready to Partner With Us?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Submit your wholesale inquiry today and let's discuss how we can support your business.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button size="lg" className="bg-white text-blue-600 hover:bg-blue-50 px-8 py-6 text-lg">
                Submit Inquiry
              </Button>
            </Link>
            <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer">
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white/20 px-8 py-6 text-lg"
              >
                <MessageCircle className="mr-2 h-5 w-5" />
                Chat Now
              </Button>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
