import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { MessageCircle, Mail, MapPin, Phone } from "lucide-react";
import { z } from "zod";

const WHATSAPP_NUMBER = "07082769477";
const STORE_ADDRESS = "Oke Baale, Ona Baba Ona, Osogbo, Osun State";

const inquirySchema = z.object({
  companyName: z.string().min(2, "Company name must be at least 2 characters"),
  contactPerson: z.string().min(2, "Contact person name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email"),
  phone: z.string().min(10, "Please enter a valid phone number"),
  businessType: z.string().optional(),
  productsOfInterest: z.string().optional(),
  desiredQuantity: z.string().optional(),
  message: z.string().optional(),
});

export default function Contact() {
  const [formData, setFormData] = useState({
    companyName: "",
    contactPerson: "",
    email: "",
    phone: "",
    businessType: "",
    productsOfInterest: "",
    desiredQuantity: "",
    message: "",
  });

  const [inquiryList, setInquiryList] = useState<any[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const submitInquiry = trpc.inquiries.submit.useMutation();

  // Load inquiry list from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("inquiryList");
    if (saved) {
      try {
        setInquiryList(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load inquiry list:", e);
      }
    }
  }, []);

  // Pre-fill products of interest from inquiry list
  useEffect(() => {
    if (inquiryList.length > 0) {
      const products = inquiryList
        .map((item) => `${item.name} (${item.inquiryQuantity} units)`)
        .join(", ");
      setFormData((prev) => ({
        ...prev,
        productsOfInterest: products,
      }));
    }
  }, [inquiryList]);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Validate form data
      const validatedData = inquirySchema.parse(formData);

      // Submit inquiry
      await submitInquiry.mutateAsync(validatedData);

      // Clear inquiry list after successful submission
      localStorage.removeItem("inquiryList");
      setInquiryList([]);

      // Show success message
      toast.success("Inquiry submitted successfully! We'll contact you soon.");

      // Reset form
      setFormData({
        companyName: "",
        contactPerson: "",
        email: "",
        phone: "",
        businessType: "",
        productsOfInterest: "",
        desiredQuantity: "",
        message: "",
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const firstError = error.issues[0];
        toast.error(firstError?.message || "Validation error");
      } else {
        toast.error("Failed to submit inquiry. Please try again.");
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleWhatsAppClick = () => {
    const text = encodeURIComponent(
      `Hello Luxe Vita Store,\n\nCompany: ${formData.companyName}\nContact: ${formData.contactPerson}\nEmail: ${formData.email}\nPhone: ${formData.phone}\n\nProducts of Interest: ${formData.productsOfInterest}\n\nMessage: ${formData.message}`
    );
    window.open(`https://wa.me/${WHATSAPP_NUMBER.replace(/\D/g, "")}?text=${text}`, "_blank");
  };

  return (
    <div className="min-h-screen bg-background pt-24 pb-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Contact & Inquiry Portal
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Submit your wholesale inquiry and we'll get back to you shortly
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {/* Contact Information */}
          <div className="lg:col-span-1 space-y-6">
            {/* WhatsApp Card */}
            <Card className="p-6 bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 border-green-200 dark:border-green-800">
              <div className="flex items-start gap-4">
                <MessageCircle className="w-8 h-8 text-green-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-foreground mb-2">WhatsApp</h3>
                  <a
                    href={`https://wa.me/${WHATSAPP_NUMBER.replace(/\D/g, "")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-green-600 hover:text-green-700 font-medium"
                  >
                    {WHATSAPP_NUMBER}
                  </a>
                  <p className="text-sm text-muted-foreground mt-2">
                    Available 24/7 for quick inquiries
                  </p>
                </div>
              </div>
            </Card>

            {/* Email Card */}
            <Card className="p-6">
              <div className="flex items-start gap-4">
                <Mail className="w-8 h-8 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-foreground mb-2">Email</h3>
                  <a
                    href="mailto:inquiries@luxevitastore.com"
                    className="text-primary hover:underline"
                  >
                    inquiries@luxevitastore.com
                  </a>
                  <p className="text-sm text-muted-foreground mt-2">
                    We'll respond within 24 hours
                  </p>
                </div>
              </div>
            </Card>

            {/* Location Card */}
            <Card className="p-6">
              <div className="flex items-start gap-4">
                <MapPin className="w-8 h-8 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-foreground mb-2">Location</h3>
                  <p className="text-sm text-muted-foreground mb-2">{STORE_ADDRESS}</p>
                  <p className="text-sm text-muted-foreground">
                    Visit us by appointment
                  </p>
                </div>
              </div>
            </Card>

            {/* Phone Card */}
            <Card className="p-6">
              <div className="flex items-start gap-4">
                <Phone className="w-8 h-8 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-foreground mb-2">Phone</h3>
                  <a href={`tel:${WHATSAPP_NUMBER}`} className="text-primary hover:underline">
                    {WHATSAPP_NUMBER}
                  </a>
                  <p className="text-sm text-muted-foreground mt-2">
                    Call for urgent matters
                  </p>
                </div>
              </div>
            </Card>
          </div>

          {/* Inquiry Form */}
          <div className="lg:col-span-2">
            <Card className="p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Company Information */}
                <div>
                  <h3 className="text-lg font-semibold text-foreground mb-4">
                    Company Information
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="companyName">Company Name *</Label>
                      <Input
                        id="companyName"
                        name="companyName"
                        value={formData.companyName}
                        onChange={handleInputChange}
                        placeholder="Your company name"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="businessType">Business Type</Label>
                      <Select
                        value={formData.businessType}
                        onValueChange={(value) => handleSelectChange("businessType", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select business type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="retail">Retail Store</SelectItem>
                          <SelectItem value="distributor">Distributor</SelectItem>
                          <SelectItem value="reseller">Reseller</SelectItem>
                          <SelectItem value="corporate">Corporate/Institutional</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                {/* Contact Information */}
                <div>
                  <h3 className="text-lg font-semibold text-foreground mb-4">
                    Contact Information
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="contactPerson">Contact Person *</Label>
                      <Input
                        id="contactPerson"
                        name="contactPerson"
                        value={formData.contactPerson}
                        onChange={handleInputChange}
                        placeholder="Full name"
                        required
                      />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="email">Email Address *</Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          placeholder="your@email.com"
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="phone">Phone/WhatsApp *</Label>
                        <Input
                          id="phone"
                          name="phone"
                          value={formData.phone}
                          onChange={handleInputChange}
                          placeholder="Your phone number"
                          required
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Product Inquiry */}
                <div>
                  <h3 className="text-lg font-semibold text-foreground mb-4">
                    Product Inquiry
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="productsOfInterest">Products of Interest</Label>
                      <Textarea
                        id="productsOfInterest"
                        name="productsOfInterest"
                        value={formData.productsOfInterest}
                        onChange={handleInputChange}
                        placeholder="List the products you're interested in"
                        rows={3}
                      />
                      {inquiryList.length > 0 && (
                        <p className="text-sm text-muted-foreground mt-2">
                          Pre-filled from your inquiry list ({inquiryList.length} items)
                        </p>
                      )}
                    </div>
                    <div>
                      <Label htmlFor="desiredQuantity">Desired Quantity</Label>
                      <Input
                        id="desiredQuantity"
                        name="desiredQuantity"
                        value={formData.desiredQuantity}
                        onChange={handleInputChange}
                        placeholder="e.g., 100 units, 50 boxes, etc."
                      />
                    </div>
                  </div>
                </div>

                {/* Message */}
                <div>
                  <Label htmlFor="message">Additional Message</Label>
                  <Textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    placeholder="Any additional information or special requests"
                    rows={4}
                  />
                </div>

                {/* Submit Buttons */}
                <div className="flex flex-col sm:flex-row gap-4 pt-4">
                  <Button
                    type="submit"
                    size="lg"
                    disabled={isSubmitting}
                    className="flex-1"
                  >
                    {isSubmitting ? "Submitting..." : "Submit Inquiry"}
                  </Button>
                  <Button
                    type="button"
                    onClick={handleWhatsAppClick}
                    variant="outline"
                    size="lg"
                    className="flex-1"
                  >
                    <MessageCircle className="mr-2 h-5 w-5" />
                    Send via WhatsApp
                  </Button>
                </div>

                <p className="text-xs text-muted-foreground text-center">
                  We respect your privacy and will only use your information to respond to your inquiry.
                </p>
              </form>
            </Card>
          </div>
        </div>

        {/* Map Section */}
        <Card className="overflow-hidden">
          <div className="aspect-video bg-slate-200 dark:bg-slate-800 flex items-center justify-center">
            <iframe
              width="100%"
              height="100%"
              frameBorder="0"
              title="Luxe Vita Store Location"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3955.8340854342467!2d4.554!3d7.776!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x103a0b0b0b0b0b0b%3A0x0b0b0b0b0b0b0b0b!2sOke%20Baale%2C%20Ona%20Baba%20Ona%2C%20Osogbo%2C%20Osun%20State!5e0!3m2!1sen!2sng!4v1234567890"
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </Card>
      </div>
    </div>
  );
}
