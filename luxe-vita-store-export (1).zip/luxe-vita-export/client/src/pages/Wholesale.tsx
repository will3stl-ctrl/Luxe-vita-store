import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Link } from "wouter";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { CheckCircle, MessageCircle, TrendingUp, Zap } from "lucide-react";

const WHATSAPP_NUMBER = "07082769477";
const WHATSAPP_URL = `https://wa.me/${WHATSAPP_NUMBER.replace(/\D/g, "")}?text=Hello%20Luxe%20Vita%20Store%2C%20I%27m%20interested%20in%20wholesale%20partnership.`;

const BENEFITS = [
  {
    icon: TrendingUp,
    title: "Competitive Pricing",
    description: "Bulk discounts and tiered pricing to maximize your profit margins",
  },
  {
    icon: Zap,
    title: "Fast Delivery",
    description: "Reliable and timely delivery to keep your inventory flowing",
  },
  {
    icon: CheckCircle,
    title: "Quality Assurance",
    description: "All products undergo strict quality checks before shipment",
  },
  {
    icon: MessageCircle,
    title: "Dedicated Support",
    description: "Personal WhatsApp support for all your wholesale needs",
  },
];

const PROCESS_STEPS = [
  {
    step: "1",
    title: "Submit Inquiry",
    description: "Fill out our wholesale inquiry form with your business details and product interests",
  },
  {
    step: "2",
    title: "Get Quotation",
    description: "Receive a customized quote based on your requirements and order volume",
  },
  {
    step: "3",
    title: "Negotiate Terms",
    description: "Discuss pricing, payment terms, and delivery schedules with our team",
  },
  {
    step: "4",
    title: "Place Order",
    description: "Confirm your order and proceed with payment via your preferred method",
  },
  {
    step: "5",
    title: "Receive Products",
    description: "Get your products delivered on schedule with full documentation",
  },
];

const FAQS = [
  {
    question: "What is the minimum order quantity (MOQ)?",
    answer:
      "MOQs vary by product category. Most products have an MOQ of 5-10 units, but we're flexible for bulk orders. Contact us for specific product MOQs.",
  },
  {
    question: "What payment methods do you accept?",
    answer:
      "We accept bank transfers, mobile money transfers, and payment on delivery for local pickups. We also offer flexible payment terms for established partners.",
  },
  {
    question: "How long does delivery take?",
    answer:
      "Local delivery in Osogbo is typically 1-2 days. For other locations in Nigeria, delivery usually takes 3-7 business days depending on the destination.",
  },
  {
    question: "Do you offer customization or branding?",
    answer:
      "Yes, we offer customization options for bulk orders. Please contact us to discuss your specific requirements and pricing.",
  },
  {
    question: "What is your return and exchange policy?",
    answer:
      "We accept returns and exchanges within 7 days of delivery for defective products. Undamaged products in original packaging can be exchanged for different sizes or colors.",
  },
  {
    question: "Can I visit the store in person?",
    answer:
      "Absolutely! We're located at Oke Baale, Ona Baba Ona, Osogbo, Osun State. We welcome visits by appointment. Contact us on WhatsApp to schedule.",
  },
  {
    question: "Do you offer wholesale pricing for small businesses?",
    answer:
      "Yes, we work with businesses of all sizes. While larger orders get better pricing, we have competitive rates for small to medium wholesale orders.",
  },
  {
    question: "How can I stay updated on new products?",
    answer:
      "Follow us on Instagram (@luxe_vita_store) and TikTok (@luxe_vita_store_backup) for product updates, or contact us to be added to our wholesale newsletter.",
  },
];

export default function Wholesale() {
  const [expandedFaq, setExpandedFaq] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-background pt-24 pb-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Wholesale Partnership Opportunities
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Join our network of successful wholesale partners and grow your business with Luxe Vita Store
          </p>
        </div>

        {/* Benefits Section */}
        <section className="mb-20">
          <h2 className="text-3xl font-bold text-foreground mb-12 text-center">Why Partner With Us?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {BENEFITS.map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
                  <Icon className="w-10 h-10 text-primary mb-4" />
                  <h3 className="text-lg font-semibold text-foreground mb-2">{benefit.title}</h3>
                  <p className="text-muted-foreground">{benefit.description}</p>
                </Card>
              );
            })}
          </div>
        </section>

        {/* Terms Section */}
        <section className="mb-20 bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-8 md:p-12">
          <h2 className="text-3xl font-bold text-foreground mb-8">Wholesale Terms & Conditions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-lg font-semibold text-foreground mb-4">Minimum Order Quantities</h3>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-primary mr-3 mt-0.5 flex-shrink-0" />
                  <span>Most products: 5-10 units minimum</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-primary mr-3 mt-0.5 flex-shrink-0" />
                  <span>Bulk orders (50+ units): Custom pricing available</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-primary mr-3 mt-0.5 flex-shrink-0" />
                  <span>Flexible MOQs for established partners</span>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-foreground mb-4">Payment Terms</h3>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-primary mr-3 mt-0.5 flex-shrink-0" />
                  <span>50% advance, 50% on delivery</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-primary mr-3 mt-0.5 flex-shrink-0" />
                  <span>Full payment upfront for new customers</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-primary mr-3 mt-0.5 flex-shrink-0" />
                  <span>Credit terms available for verified partners</span>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-foreground mb-4">Lead Times</h3>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-primary mr-3 mt-0.5 flex-shrink-0" />
                  <span>In-stock items: 1-2 days</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-primary mr-3 mt-0.5 flex-shrink-0" />
                  <span>Special orders: 5-10 business days</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-primary mr-3 mt-0.5 flex-shrink-0" />
                  <span>Customized products: 10-15 business days</span>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-foreground mb-4">Shipping Options</h3>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-primary mr-3 mt-0.5 flex-shrink-0" />
                  <span>Local pickup available in Osogbo</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-primary mr-3 mt-0.5 flex-shrink-0" />
                  <span>Nationwide delivery via courier</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-primary mr-3 mt-0.5 flex-shrink-0" />
                  <span>Bulk shipments: Custom arrangements</span>
                </li>
              </ul>
            </div>
          </div>
        </section>

        {/* Process Section */}
        <section className="mb-20">
          <h2 className="text-3xl font-bold text-foreground mb-12 text-center">How to Order</h2>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 md:gap-2">
            {PROCESS_STEPS.map((item, index) => (
              <div key={index} className="relative">
                <Card className="p-6 text-center h-full flex flex-col justify-center">
                  <div className="w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold text-lg mx-auto mb-4">
                    {item.step}
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.description}</p>
                </Card>
                {index < PROCESS_STEPS.length - 1 && (
                  <div className="hidden md:block absolute top-1/2 -right-2 w-4 h-0.5 bg-border transform -translate-y-1/2" />
                )}
              </div>
            ))}
          </div>
        </section>

        {/* FAQ Section */}
        <section className="mb-20">
          <h2 className="text-3xl font-bold text-foreground mb-12 text-center">Frequently Asked Questions</h2>
          <div className="max-w-3xl mx-auto">
            <Accordion type="single" collapsible className="w-full">
              {FAQS.map((faq, index) => (
                <AccordionItem key={index} value={`faq-${index}`}>
                  <AccordionTrigger className="text-left">{faq.question}</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">{faq.answer}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </section>

        {/* CTA Section */}
        <section className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-12 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Contact us today to discuss your wholesale requirements and receive a customized quote.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button size="lg" className="bg-white text-blue-600 hover:bg-blue-50 px-8 py-6 text-lg">
                Submit Inquiry Form
              </Button>
            </Link>
            <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer">
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white/20 px-8 py-6 text-lg"
              >
                <MessageCircle className="mr-2 h-5 w-5" />
                Chat on WhatsApp
              </Button>
            </a>
          </div>
        </section>

        {/* Contact Info */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <div>
            <h3 className="font-semibold text-foreground mb-2">WhatsApp</h3>
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary hover:underline"
            >
              {WHATSAPP_NUMBER}
            </a>
          </div>
          <div>
            <h3 className="font-semibold text-foreground mb-2">Location</h3>
            <p className="text-muted-foreground">
              Oke Baale, Ona Baba Ona<br />
              Osogbo, Osun State
            </p>
          </div>
          <div>
            <h3 className="font-semibold text-foreground mb-2">Hours</h3>
            <p className="text-muted-foreground">
              Monday - Sunday<br />
              24/7 Support Available
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
